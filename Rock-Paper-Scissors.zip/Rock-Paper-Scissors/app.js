let userScore = 0;
let compScore = 0;

let choices = document.querySelectorAll(".choice");
let msg = document.querySelector("#msg");
let userScorePara = document.querySelector("#user-score");
let compScorePara = document.querySelector("#comp-score");
let resetBtn = document.querySelector("#resetBtn");

const geCompChoice = () => {
  const options = ["rock","paper","scissors"];
  const randIdx = Math.floor(Math.random() * 3);
  return options[randIdx];
}
const drawGame = () => {
  msg.innerText = "Game was Draw. Play Again";
  msg.style.backgroundColor = "pink";
  console.log("game was draw");
}

const showWinner = (userWin,userchoice,computerchoice) => {
  if(userWin) {
    userScore++;
    userScorePara.innerText = userScore;
    msg.innerText = `You win! Your ${userchoice} beats ${computerchoice}`;
    msg.style.backgroundColor = "green";
    console.log("You Win");
  } else{
    compScore++;
    compScorePara.innerText = compScore;
    msg.innerText = `You lost. ${computerchoice} beats ${userchoice}`;
    msg.style.backgroundColor = "red";
    console.log("You lose");
  }
}
const playGame = (userchoice) => {

  const computerchoice = geCompChoice();

  if(userchoice === computerchoice) {
    drawGame();
  } else {
    let userWin = true;
    if(userchoice === "rock"){
      userWin = computerchoice === "paper" ? false : true; 
    } else if(userchoice === "paper") {
      userWin = computerchoice === "scissors" ? false : true;
    } else {
      userWin = computerchoice === "rock" ? false : true;
    }

    showWinner(userWin,userchoice,computerchoice);
  }
}

const resetGame = () => {
  userScore = 0;
  compScore = 0;
  userScorePara.innerText = 0;
  compScorePara.innerText = 0;
  msg.innerText = "Play Your move";
  msg.style.backgroundColor = "#081b31"

}

resetBtn.addEventListener("click",resetGame);

choices.forEach((choice) => {
  choice.addEventListener("click", () => {
    const userchoice = choice.getAttribute("id");
    playGame(userchoice);
  })
})


