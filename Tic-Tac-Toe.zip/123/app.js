let boxes = document.querySelectorAll(".box");
let resetBtn = document.querySelector("#reset-btn");
let newgameBtn = document.querySelector(".newBtn");
let msgContainer = document.querySelector(".msg-container");
let msg = document.querySelector("#msg")
let turnO = true;
let count = 0;

const winpatterns = [
        [0,1,2],
        [0,3,6],
        [0,4,8],
        [1,4,7],
        [2,5,8],
        [2,4,6],
        [3,4,5],
        [6,7,8]
]

boxes.forEach((box) => {
  box.addEventListener("click", () => {
    if(turnO) {
      box.innerText = "O";
      count++;
      turnO = false;
    } else {
      box.innerText = "X";
      count++;
      turnO = true;
    }
    box.disabled = true;
    console.log(count) 

    checkWinner();
  })
})

const disablebuttons = () => {
  for(let box of boxes) {
    box.disabled = true;
    count=0;
  }
};

const enablebuttons = () => {
  for(let box of boxes) {
    box.disabled = false;
    box.innerText = "";
    count = 0;
  }

}
const showWinner = (winner) =>{
  msg.innerText = `Congratulations, Winner is ${winner}`;
  msgContainer.classList.remove("hide");

};

const drawWinner = () => {
  msg.innerText = "Draw";
  msgContainer.classList.remove("hide");
}


const checkWinner = () => {
  for(let pattern of winpatterns) {
  let pos1Valu = boxes[pattern[0]].innerText;
  let pos2Valu = boxes[pattern[1]].innerText;
  let pos3Valu = boxes[pattern[2]].innerText;

  if(pos1Valu != "" && pos2Valu != "" && pos3Valu != "") {
    if(pos1Valu === pos2Valu && pos2Valu === pos3Valu) {
      showWinner(pos1Valu);
    }
    else if(count === 9){
      drawWinner();
    }
  } 
}
}

const resetGame = () => {
  turnO = true;
  enablebuttons();
  msgContainer.classList.add("hide");

}

newgameBtn.addEventListener("click", resetGame);
resetBtn.addEventListener("click",resetGame);